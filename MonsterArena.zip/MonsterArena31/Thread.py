from threading import Thread
from MonsterArena3 import Sprites
from Heroi import Heroi

class Th(Thread):

    def __init__ (self, num):
        Thread.__init__(self)
        self.num = num

    def run(self):
        warrior = Heroi("./warrior_c.png", 8, 5)