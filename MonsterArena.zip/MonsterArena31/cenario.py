import pygame
from pygame import QUIT
from random import randint
from Heroi import Heroi


def desenho(sur, scenary):
    comp = 800/16
    alt = 600/16
    for l in range(16):
        for c in range(16):
            celula = scenary[l][c]
            x = c*comp
            y = l*alt
            pygame.draw.rect(sur, (255, 255, 0), ((x, y), (comp, alt)), 1)
            
            if(celula <> 0):
                celula.x = x
                celula.y = y
                celula.comp = comp
                celula.alt = alt
                celula.draw(sur)

pygame.init()

screen = pygame.display.set_mode((800, 600), 0, 32)

cenario = [[0 for _ in range(16)] for _ in range(16)] #cenario 16x16

#--------------------------------------------------------------------

for z in range(32): #local random para aparecer zumbis
    terrain = pygame.image.load("./terrain_1.png")
    l = randint(0, 15)
    c = randint(0, 15)
    cenario[l][c] = terrain

for l in range(16):
    for c in range(16):
        celula = cenario[l][c]
        if(celula == 0):
            print ".",
        else:
            print celula.toText(),
            print ""

#---------------------------------------------------------------------

for z in range(5): #local random para aparecer a faca
    terrain_2 = pygame.image.load("./terrain_2.png")
    l = randint(0, 10)
    c = randint(0, 10)
    cenario[l][c] = terrain_2

#---------------------------------------------------------------------

#def atacar(self, zumbi): #ataque do heroi e do zumbi
    #zumbi.Life -= self.dano
    
    #if(zumbi.Life > 0):
        #self.Life = zumbi.dano
        #if(self.Life <= 0):
            #self.morto = True
    #else:
        #zumbi.morto = True
        
#---------------------------------------------------------------------

for z in range(1): #local random para aparecer o heroi
    hero = Heroi(100, 50)
    l = randint(0, 10)
    c = randint(0, 10)
    cenario[l][c] = hero
    
#---------------------------------------------------------------------

while(True):
    desenho(screen, cenario)
    pygame.display.update()
    for e in pygame.event.get():
        if e.type == QUIT:
            exit()
