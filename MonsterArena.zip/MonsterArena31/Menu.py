import pygame


class Menu():
    
    def __init__(self):
        self.x = 0
        self.y = 0
        self.background = pygame.image.load("./menu.png")
               
    def draw(self,sur):
        quadro = self.retornaQuadro()
        sur.blit(quadro,(self.x,self.y))
        
    def retornaQuadro(self):
        quadros = self.estados[self.estado]
        self.numeroQuadro = self.numeroQuadro % len(quadros)
        indImagem = quadros[self.numeroQuadro]
        imagem = self.epa_images[indImagem]    
        self.numeroQuadro = self.numeroQuadro + 1
    
        return imagem
        
