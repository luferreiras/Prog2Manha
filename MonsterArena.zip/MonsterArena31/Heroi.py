import pygame
from pygame.locals import *



class Heroi():
    
    def __init__(self,imageNome,linhas,colunas):
        self.x = 600
        self.y = 350
        self.velY = 0
        self.velX = 0
        self.life = 500
        self.ataque = 50
        self.img = pygame.image.load(imageNome)
        self.epa_images = []
        self.XP = 0
        self.level = 0
        
        
        
        self.width = self.img.get_width() / colunas
        self.height = self.img.get_height() / linhas
        
        self.imgLevelUp = pygame.image.load("./levelup.png")
        
        for linha in range(linhas):
            for coluna in range(colunas):
                x = coluna * self.width 
                y = linha * self.height
                frame = self.img.subsurface((x,y),(self.width,self.height))
                self.epa_images.append(frame)
                               
        epaCima = [0, 1, 2, 3, 4]
        epaBaixo = [10, 11, 12, 13, 14]
        epaEsquerda = [5, 6, 7, 8, 9]
        epaDireita = [15, 16, 17, 18, 19]
        epaAtaqueCima = [20, 21, 22, 23, 24]
        epaAtaqueBaixo = [30, 31, 32, 33, 34]
        epaAtaqueEsquerda = [25, 26, 27, 28, 29]
        epaAtaqueDireita = [35, 36, 37, 38, 39]

        epaParadoCima = [0]
        epaParadoBaixo = [10]
        epaParadoEsquerda = [5]
        epaParadoDireita = [15]

        self.estados = {"CIMA": epaCima,
                        "BAIXO":epaBaixo,
                        "ESQUERDA":epaEsquerda,
                        "DIREITA":epaDireita,
                        "PARADO":epaParadoCima,
                        "PARADOESQ":epaParadoEsquerda,
                        "PARADODIR":epaParadoDireita ,
                        "PARADOBAIXO":epaParadoBaixo,
                        "ATKCIMA": epaAtaqueCima,
                        "ATKBAIXO": epaAtaqueBaixo,
                        "ATKESQUERDA": epaAtaqueEsquerda,
                        "ATKDIREITA": epaAtaqueDireita}

        self.estado = "PARADOBAIXO"
        self.numeroQuadro = 0
        self.rect = Rect ( (600, 350), (self.width -20, self.height - 20) )
       
            
        
    def retornaQuadro(self):
        quadros = self.estados[self.estado]
        self.numeroQuadro = self.numeroQuadro % len(quadros)
        indImagem = quadros[self.numeroQuadro]
        imagem = self.epa_images[indImagem]    
        self.numeroQuadro = self.numeroQuadro + 1
    
        return imagem
    
    def drawHeroi(self,sur):
        
        quadro = self.retornaQuadro()
        sur.blit(quadro,(self.rect.x,self.rect.y))

    def testaMovimento(self):
        r = Rect ( (self.rect.x  + self.velX, self.rect.y + self.velY), self.rect.size)
        
        return r
        
    def update(self):
        if (self.velX == 0 and self.velY == 0 and self.estado == "CIMA" ):
            self.estado = "PARADO"
        elif (self.velX == 0 and self.velY == 0 and self.estado == "BAIXO" ):
            self.estado = "PARADOBAIXO"
        elif (self.velX == 0 and self.velY == 0 and self.estado == "ESQUERDA" ):
            self.estado = "PARADOESQ"
        elif (self.velX == 0 and self.velY == 0 and self.estado == "DIREITA" ):
            self.estado = "PARADODIR"
                    
        else:
            self.rect.x += self.velX
            self.rect.y += self.velY
            if(self.rect.x <= 0 ):
                self.velX = 0
            if(self.rect.y <= 0 ):
                self.velY = 0
            if(self.rect.x >= 1300 ):
                self.velX = 0
            if(self.rect.y >= 600 ):
                self.velY = 0   
                         
    def levelUp(self,sur):
        self.victory = pygame.mixer.Sound("./Victory1.ogg")
        self.victory.set_volume(0.1)
        
        if (self.XP >= 100 and self.XP <= 110):
            self.victory.play(-1)
            self.victory.fadeout(2000)
            self.level += 1
            sur.blit(self.imgLevelUp,(0,0 ))
            if (self.life < 500 and self.life > 100):
                self.life += 100
           
        if (self.XP >= 400 and self.XP <= 610):
            self.victory.play(-1)
            self.victory.fadeout(2000)
            self.level += 1
            sur.blit(self.imgLevelUp,(0,0 ))
            if (self.life < 500 and self.life > 100):
                self.life += 100
            
        if (self.XP >= 600 and self.XP <= 810):
            self.victory.play(-1)
            self.victory.fadeout(2000) 
            self.level += 1
            sur.blit(self.imgLevelUp,(0 ,0 ))
            if (self.life < 500 and self.life > 100):
                self.life += 100
            
        if (self.XP >= 800 and self.XP <= 910):
            self.victory.play(-1)
            self.victory.fadeout(2000)
            self.level += 1
            sur.blit(self.imgLevelUp,(0 ,0))
            if (self.life < 500 and self.life > 100):
                self.life += 100
            
        if (self.XP >= 1000 and self.XP <= 1110):
            self.victory.play(-1)
            self.victory.fadeout(2000)
            self.level += 1
            sur.blit(self.imgLevelUp,(0 ,0))
            if (self.life < 500 and self.life > 100):
                self.life += 100
            
        if(self.life <= 0):
            self.victory.stop()
         
        
