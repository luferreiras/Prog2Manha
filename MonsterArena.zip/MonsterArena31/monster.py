import pygame,math,time
from random import randint
from pygame.locals import *
from Heroi import Heroi
from drop import Drop


class Monstro():
    
    def __init__(self,imageNome,linhas,colunas,vida,dano,velX,velY):
        self.x = randint(0,1378)
        self.y = randint(0,700)
        self.velY = velY
        self.velX = velX
        self.dano = dano
        self.vivo = True
        self.drop = False
        
        self.vidaMonstro = vida
                
        self.img = pygame.image.load(imageNome)
        self.imgMorto = pygame.image.load("./death2.png")
        
        self.imgSlash = pygame.image.load("./d4.png")
        
        self.imgBurn1 = pygame.image.load("./burn_1.png")
        
        self.imgburn = [pygame.image.load("./burn_2.png"),pygame.image.load("./burn_3.png"),pygame.image.load("./burn_4.png")]
        
        
        self.imgLife = pygame.image.load("./lf3.png")
        
               
        self.epa_images = []
        
        self.width = self.img.get_width() / colunas
        self.height = self.img.get_height() / linhas
        
        for linha in range(linhas):
            for coluna in range(colunas):
                x = coluna * self.width 
                y = linha * self.height
                frame = self.img.subsurface((x,y),(self.width,self.height))
                self.epa_images.append(frame)
                               
        epaCima = [9, 10, 11]
        epaBaixo = [0, 1, 2]
        epaEsquerda = [3, 4, 5 ]
        epaDireita = [6, 7, 8]

        epaParadoCima = [0]
        epaParadoBaixo = [10]
        epaParadoEsquerda = [5]
        epaParadoDireita = [15]

        self.estados = {"CIMA": epaCima,
                        "BAIXO":epaBaixo,
                        "ESQUERDA":epaEsquerda,
                        "DIREITA":epaDireita,
                        "PARADO":epaParadoCima,
                        "PARADOESQ":epaParadoEsquerda,
                        "PARADODIR":epaParadoDireita,
                        "PARADOBAIXO":epaParadoBaixo}

        self.estado = "PARADOBAIXO"
        self.numeroQuadro = 0
        self.rect = Rect ( (self.x, self.y), (self.width - 25, self.height - 25) )
    def retornaQuadro(self):
        quadros = self.estados[self.estado]
        self.numeroQuadro = self.numeroQuadro % len(quadros)
        indImagem = quadros[self.numeroQuadro]
        imagem = self.epa_images[indImagem]    
        self.numeroQuadro = self.numeroQuadro + 1
    
        return imagem
    
    def drawMonster(self,sur):
        
        
        
        quadro = self.retornaQuadro()
        
        if(self.vivo == True):
            sur.blit(quadro,(self.rect.x,self.rect.y))
       
        if(self.vivo == False and self.vidaMonstro <= 0):
            
            sur.blit(self.imgMorto,(self.rect.x ,self.rect.y ))
            self.dano = 0        
                
    def testaMovimento(self):
        r = Rect ( (self.rect.x + self.velX, self.rect.y + self.velY), self.rect.size)
        return r
 
                
    def moverMonstro(self, Heroi):
        
        if self.rect.x > Heroi.rect.x:
            self.rect.x -= self.velX
            if(Heroi.estado == "ESQUERDA"):
                self.estado = "ESQUERDA"
        elif self.rect.x < Heroi.rect.x:
            self.rect.x += self.velX
            if(Heroi.estado == "DIREITA"):
                self.estado = "DIREITA"
        
        if self.rect.y < Heroi.rect.y:
            self.rect.y += self.velY
            if (Heroi.estado == "BAIXO"):
                self.estado = "BAIXO"
            
        elif self.rect.y > Heroi.rect.y:
            self.rect.y -= self.velY
            if (Heroi.estado == "CIMA"):
                self.estado = "CIMA"
            
    def tomouDano(self):
        self.velX = -10
        self.velY = -10
       
        
    def recuperaDano(self):
        
        if (self.vidaMonstro <= 0):
            self.velX = 0
            self.velY = 0
            self.vivo = False
            self.dano = 0
            
        else:
            self.velX += 1.5
            self.velY += 1.5
            
        
            
    def atacaPlayer(self,Heroi):
        
        if(self.vivo == True and self.vidaMonstro > 0):
            Heroi.life -= self.dano
            
    def drawSlash(self,sur):
           
        if(self.vivo == True):
            
            sur.blit(self.imgSlash,(self.rect.x ,self.rect.y ))
            