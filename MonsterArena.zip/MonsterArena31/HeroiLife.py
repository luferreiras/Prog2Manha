import pygame
from pygame.locals import *


class HeroiLife():
    
    def __init__(self,life):
        self.x = 0
        self.y = 0
        
        self.life = 500
        
        self.img1 = pygame.image.load("./life_full.png ")
        self.img2 = pygame.image.load("./life_3-4.png ")
        self.img3 = pygame.image.load("./life_2-4.png ")
        self.img4 = pygame.image.load("./life_1-4.png ")
        self.img5 = pygame.image.load("./life_0-4.png ")
        
 
    
    def draw(self,sur):
        
        if (self.life >= 500):
            sur.blit(self.img1,(self.x,self.y))
        if (self.life >= 400 and self.life < 500):
            sur.blit(self.img2,(self.x,self.y))
        if (self.life >= 300 and self.life < 400):
            sur.blit(self.img3,(self.x,self.y))
        if (self.life >= 200 and self.life < 300):
            sur.blit(self.img3,(self.x,self.y))
        if (self.life >= 100 and self.life < 200):
            sur.blit(self.img4,(self.x,self.y))    
        if (self.life < 100 and self.life > 0):
            sur.blit(self.img4,(self.x,self.y))    
        if (self.life <= 0 ):
            sur.blit(self.img5,(self.x,self.y))    

        
    def update(self,sur):
        if (self.life >= 500):
            sur.blit(self.img1,(self.x,self.y))
        if (self.life == 400):
            sur.blit(self.img2,(self.x,self.y))
        if (self.life == 300):
            sur.blit(self.img3,(self.x,self.y))
        if (self.life == 200):
            sur.blit(self.img3,(self.x,self.y))
        if (self.life == 100):
            sur.blit(self.img4,(self.x,self.y))    
        if (self.life <= 0):
            sur.blit(self.img5,(self.x,self.y))          
      
