from Sprites import telaInicio, pintarLabirinto
from Heroi import Heroi

class Setup():
    rodarJogo = Thread(1)
    telaInicio = Thread(2)
    pintarLabirinto = Thread(3)
    levelUp = Thread(4)
    drawHeroi = Thread(5)
    drawMonster = Thread(6)
    moverMagia = Thread(7)
    
    
    moverMagia.run()
    drawMonster.run()
    drawHeroi.run()
    levelUp.run()
    telaInicio.run()
    pintarLabirinto.run()
    rodarJogo.run()
    
    
