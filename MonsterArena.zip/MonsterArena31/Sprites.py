#-*-coding:Latin-*-
import pygame, random
from pygame.locals import *
from Heroi import Heroi
from random import randint
from monster import Monstro
from HeroiLife import HeroiLife
from  drop import Drop
from magia import Magia
from threading import Thread


matriz = [
             
          [0, 0, 0, 3, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3],
          [0, 0, 0, 0, 0, 3, 0, 0, 2, 0, 3, 3, 0, 0, 3, 3],
          [0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 3],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 3, 0, 0],
          [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
          [3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0],
          [3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0],
          [3, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3],
          [3, 3, 0, 0, 2, 0, 0, 0, 0, 0, 0, 2, 0, 2, 3, 3],
          [3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3],
             
             ]


FPS = 30
FPSCLOCK = pygame.time.Clock()

screenLabirinto = pygame.display.set_mode((1380, 700), 0, 32)

width = screenLabirinto.get_width() / len ( matriz[0])
height = screenLabirinto.get_height() / len ( matriz )

terrain = pygame.image.load("./terrain.png")
terrain2 = pygame.image.load("./terrain2.png")
terrain3 = pygame.image.load("./terrain3.png")

terrain = pygame.transform.scale(terrain, (width, height))
terrain2 = pygame.transform.scale(terrain2, (width, height))
terrain3 = pygame.transform.scale(terrain3, (width, height))

warrior = Heroi("./warrior_c.png", 8, 5)

monster1 = Monstro("./m1.png", 4, 5,250,20,5,5)
monster2 = Monstro("./m2_moving.png", 4, 5,400,30,6,6)
magia = Magia("./plasma.png",4,5,warrior)


def telaInicio():
    titleRect = pygame.image.load("./menu.png").get_rect()
    topCoord = -25 
    titleRect.top = topCoord
    titleRect.centerx = 650
    topCoord += titleRect.height

             
    screen.fill((0,0,0))
            
    screen.blit(pygame.image.load("./menu.png"),titleRect)

            
    while True:
        menuGameOver.stop()
        musicaMenu.play(-1)
        for event in pygame.event.get():
            if event.type == QUIT:
                exit()
            elif event.type == KEYDOWN:
                musicaMenu.stop()
                if event.key == K_ESCAPE:
                    exit()
                return 

        pygame.display.update()
        FPSCLOCK.tick()

def telaGameOver():
    
    titleRect = pygame.image.load("./game_over_base.png").get_rect()
    topCoord = -25 
    titleRect.top = topCoord
    titleRect.centerx = 650
    topCoord += titleRect.height

             
    screen.fill((0,0,0))

            
    screen.blit(pygame.image.load("./game_over_base.png"),titleRect)

    while True:
        enemyHit.stop()
        playerDash.stop()
        
        menuGameOver.play(-1)
        for event in pygame.event.get():
            if event.type == QUIT:
                exit()
            elif event.type == KEYDOWN:
                if event.key == K_SPACE:
                    telaInicio()
                    rodaJogo()
                if event.key == K_ESCAPE:
                    exit()
                
                return 

        pygame.display.update()
        FPSCLOCK.tick()

def dimensoesCelula(surface, qtdColunas, qtdLinhas):
    comprimento = surface.get_width() / qtdColunas
    altura = surface.get_height() / qtdLinhas
    return (comprimento, altura)

def pintarLabirinto(sur):
    global screen, width, height, listaObjetosDuros
    listaObjetosDuros = []
    for l in range(len(matriz)):
        for c in range(len(matriz[0])):
            
            celula = matriz[l][c]
            
            x = c * width
            y = l * height
            
            r = Rect( (x, y), (width, height) )
               
                
            imagem = terrain
            if (celula == 2):
                imagem = terrain2
                listaObjetosDuros.append(r)
            elif (celula == 1):
                imagem = terrain3
                listaObjetosDuros.append(r)
            
            
            sur.blit(imagem, r.topleft)
     
pygame.init()

screen = pygame.display.set_mode((1378,700),0,32)

sword = pygame.mixer.Sound("./sword.ogg")
sword.set_volume(0.2)

musicaMenu = pygame.mixer.Sound("./menu.ogg")
musicaMenu.set_volume(0.1)

menuGameOver = pygame.mixer.Sound("./Gameover2.ogg")
menuGameOver.set_volume(0.1)

enemyHit = pygame.mixer.Sound("./Damage3.ogg")
enemyHit.set_volume(0.2)

playerDash = pygame.mixer.Sound("./Wind7.ogg")
playerDash.set_volume(0.2)

i = 0

telaInicio()


def rodaJogo():
   
    warrior = Heroi("./warrior_c.png", 8, 5)
    
    
    if(warrior.level >= 0 or warrior.level == 1):
        monster2 = Monstro("./new_m7.png", 4, 3,250,15,5,5)
    if(warrior.level == 2):
        monster2 = Monstro("./new_m8.png", 4, 3,300,10,6,6)
    if(warrior.level == 3):
        monster2 = Monstro("./new_m10.png", 4, 3,350,10,6,6)
    if(warrior.level == 4):
        monster2 = Monstro("./new_m9.png", 4, 3,450,10,6,6)
    if(warrior.level == 5):
        monster2 = Monstro("./new_m10.png", 4, 3,500,15,6,6)
        
    if(warrior.level >= 0 or warrior.level == 1):
        monster1 = Monstro("./new_m9.png", 4, 3,400,10,6,6)
    if(warrior.level == 2):
        monster1 = Monstro("./new_m5.png", 4, 3,400,10,6,6)
    if(warrior.level == 3):
        monster1 = Monstro("./new_m6.png", 4, 3,350,10,6,6)
    if(warrior.level == 4):
        monster1 = Monstro("./new_m7.png", 4, 3,300,13,6,6)
    if(warrior.level == 5):
        monster1 = Monstro("./new_m8.png", 4, 3,450,15,6,6)    
                
 
    

    magia = Magia("./plasma.png",4,5,warrior)
    
    
    
    vida = HeroiLife(warrior.life)
     
    pegaTempo = pygame.time.get_ticks()
    pegaTempo1 = pygame.time.get_ticks()
    cooldown = 10000  
    
                
    while(True):
        screen.fill((0,0,0))
    
        pintarLabirinto(screen)
        
        monster1.drawMonster(screen)
        
        monster2.drawMonster(screen)
                  
        magia.draw(screen)
          
        warrior.drawHeroi(screen)
        
        vida.draw(screen)
        
        pygame.display.update()
        
  
        for e in pygame.event.get():
            if(e.type == QUIT):
                exit()
                
            elif(e.type == KEYDOWN):
                
                if(e.key == K_ESCAPE):
                    exit()
                
                if(e.key == K_s):
                    warrior.estado = "BAIXO"    
                    warrior.velY = +10
                    
                if(e.key == K_w):
                    warrior.estado = "CIMA"
                    warrior.velY = -10
                    
                if(e.key == K_d):
                    warrior.estado = "DIREITA"
                    warrior.velX = +10
                
                if(e.key == K_a):
                    warrior.estado = "ESQUERDA"
                    warrior.velX = -10
                if(e.key == K_UP):
                    sword.play(-1)
                    warrior.estado = "ATKCIMA"
                    
            
                if(e.key == K_DOWN):
                    sword.play(-1)
                    warrior.estado = "ATKBAIXO"
                    
                    
                if(e.key == K_LEFT):
                    sword.play(-1)
                    warrior.estado = "ATKESQUERDA"
                    
                     
                if(e.key == K_RIGHT):
                    sword.play(-1)
                    warrior.estado = "ATKDIREITA"
                 
                if(e.key == K_e and magia.usouMagia == False):
                    if(warrior.estado == "DIREITA" ):
                        magia.rect.x = warrior.rect.x
                        magia.rect.y = warrior.rect.y
                        magia.velX = 10
                        magia.velY = 10
                        magia.estado = "DIREITA"
                          
                    if(warrior.estado == "ESQUERDA"):
                        magia.rect.x = warrior.rect.x
                        magia.rect.y = warrior.rect.y
                        magia.velX = 10
                        magia.velY = 10
                        magia.estado = "ESQUERDA"
                        
                    if(warrior.estado == "BAIXO" ):
                        magia.rect.x = warrior.rect.x
                        magia.rect.y = warrior.rect.y
                        magia.velX = 10
                        magia.velY = 10
                        magia.estado = "BAIXO"
                        
                    if(warrior.estado == "CIMA" ):
                        magia.rect.x = warrior.rect.x
                        magia.rect.y = warrior.rect.y
                        magia.velX = 10
                        magia.velY = 10
                        magia.estado = "CIMA"
                        
                    if(warrior.estado == "PARADODIR" ):
                        magia.rect.x = warrior.rect.x
                        magia.rect.y = warrior.rect.y
                        magia.velX = 10
                        magia.velY = 10
                        magia.estado = "DIREITA"
                           
                    if(warrior.estado == "PARADOESQ"):
                        magia.rect.x = warrior.rect.x
                        magia.rect.y = warrior.rect.y
                        magia.velX = 10
                        magia.velY = 10
                        magia.estado = "ESQUERDA"
                        
                    if(warrior.estado == "PARADOBAIXO"):
                        magia.rect.x = warrior.rect.x
                        magia.rect.y = warrior.rect.y
                        magia.velX = 10
                        magia.velY = 10
                        magia.estado = "BAIXO"
                        
                    if(warrior.estado == "PARADO" ):
                        magia.rect.x = warrior.rect.x
                        magia.rect.y = warrior.rect.y
                        magia.velX = 10
                        magia.velY = 10
                        magia.estado = "CIMA"
                        
                        
                    
                if(e.key == K_SPACE):
                    playerDash.play(-1)
                    enemyHit.stop()
                    if(warrior.estado == "DIREITA"):
                        warrior.velX = +50
                    if(warrior.estado == "ESQUERDA"):
                        warrior.velX = -50
                    if(warrior.estado == "CIMA"):
                        warrior.velY = -50
                    if(warrior.estado == "BAIXO"):
                        warrior.velY = +50
                
                
                    
                              
            elif(e.type == KEYUP):
                if(e.key == K_w):
                    warrior.velY = 0    
                if(e.key == K_a):                            
                    warrior.velX = 0                
                if(e.key == K_d):                               
                    warrior.velX = 0               
                if(e.key == K_s):                
                    warrior.velY = 0
                if(e.key == K_UP):
                    sword.stop()
                    warrior.estado = "PARADO"
                if(e.key == K_DOWN):
                    sword.stop()
                    warrior.estado = "PARADOBAIXO"
                if(e.key == K_LEFT):
                    sword.stop()
                    warrior.estado = "PARADOESQ"
                if(e.key == K_RIGHT):
                    sword.stop()
                    warrior.estado = "PARADODIR"
                
                
                
                if(e.key == K_SPACE):
                    playerDash.stop()
                    warrior.velX = 0
                    warrior.velY = 0
    
        rectColisaoWarrior = warrior.testaMovimento() 
        rectColisaoMonstro = monster1.testaMovimento()
        rectColisaoMonstro1 = monster2.testaMovimento()
        rectColisaoMagia = magia.testaMovimento()
                
        #pygame.draw.rect(screen,(255,255,255),(rectColisaoWarrior),2)
        #pygame.draw.rect(screen,(255,255,255),(rectColisaoMonstro),2)
        #pygame.draw.rect(screen,(255,255,255),(rectColisaoMonstro1),2)
        #pygame.draw.rect(screen,(255,255,255),(rectColisaoMagia),2)
        
        if (rectColisaoMagia.colliderect(monster1 )):
                
                monster1.vidaMonstro = 0
                magia.usouMagia = True
                magia.velX = 0
                magia.velY = 0
                magia.rect.x = -15
                magia.rect.y = -15
                
                if(monster1.vidaMonstro <= 0):
                    monster1.vivo = False
                    monster1.velX = 0
                    monster1.velY = 0
                    
                
        if (rectColisaoMagia.colliderect(monster2 )):
                
                monster2.vidaMonstro = 0
                magia.usouMagia = True
                magia.velX = 0
                magia.velY = 0
                magia.rect.x = -15
                magia.rect.y = -15
               
                
                if(monster2.vidaMonstro <= 0):
                    monster2.vivo = False
                    monster2.velX = 0
                    monster2.velY = 0
                    
        
        if (rectColisaoWarrior.colliderect(monster1 )):
            
         
            
            if(warrior.estado == "ATKCIMA" or warrior.estado == "ATKBAIXO" or warrior.estado == "ATKDIREITA" or warrior.estado == "ATKESQUERDA" and monster1.vivo == True and monster1.vidaMonstro > 0 ):
                enemyHit.stop()
                monster1.tomouDano()
                monster1.vidaMonstro -= warrior.ataque
                monster1.drawSlash(screen)
                
               
            if(warrior.estado == "CIMA" or warrior.estado == "BAIXO" or warrior.estado == "DIREITA" or warrior.estado == "ESQUERDA" or warrior.estado == "PARADO" or warrior.estado == "PARADODIR" or warrior.estado == "PARADOESQ" or warrior.estado == "PARADOBAIXO" and monster1.vivo == True and monster1.vidaMonstro > 0 ):
                enemyHit.play(-1) 
                
                 
                monster1.atacaPlayer(warrior)
                
                 
                vida.life = warrior.life
                
                   
                if vida.life <= 0:
                    tentar = 0
                    enemyHit.stop()
                    telaGameOver()
            
        else:
            enemyHit.stop()        
           
        
        if (rectColisaoWarrior.colliderect(monster2 )):
           
            
            if(warrior.estado == "ATKCIMA" or warrior.estado == "ATKBAIXO" or warrior.estado == "ATKDIREITA" or warrior.estado == "ATKESQUERDA"  and monster2.vivo == True and monster2.vidaMonstro > 0):
                enemyHit.stop()
            
                monster2.tomouDano()
                monster2.vidaMonstro -= warrior.ataque
                monster2.drawSlash(screen)
                
               
            if(warrior.estado == "CIMA" or warrior.estado == "BAIXO" or warrior.estado == "DIREITA" or warrior.estado == "ESQUERDA" or warrior.estado == "PARADO" or warrior.estado == "PARADODIR" or warrior.estado == "PARADOESQ" or warrior.estado == "PARADOBAIXO" and monster2.vivo == True and monster2.vidaMonstro > 0):
                enemyHit.play(-1)
                      
                monster2.atacaPlayer(warrior)
            
                vida.life = warrior.life
                   
                if vida.life <= 0:
                    enemyHit.stop()
                    telaGameOver()
            
        else:
            enemyHit.stop()        
                      
          
        if(monster1.velX < 5 or monster1.velY < 5):
            monster1.recuperaDano()
            enemyHit.stop()
        if(monster2.velX < 5 or monster2.velY < 5):
            monster2.recuperaDano()
            enemyHit.stop()
            
        if(monster2.vidaMonstro <= 0 and monster2.vivo == False):
            
            agora1 = pygame.time.get_ticks()
            
            if(monster1.vivo == True and monster2.vivo == False):
                monster2.dano = 0
            
            if (agora1 - pegaTempo1 >= cooldown):
                pegaTempo1 = agora1
                warrior.XP += 25
                magia.usouMagia = False
                if(warrior.level >= 0 or warrior.level == 1):
                    monster2 = Monstro("./new_m6.png", 4, 3,250,20,5,5)
                if(warrior.level == 2):
                    monster2 = Monstro("./new_m3.png", 4, 3,300,15,6,6)
                if(warrior.level == 3):
                    monster2 = Monstro("./new_m4.png", 4, 3,350,15,6,6)
                if(warrior.level == 4):
                    monster2 = Monstro("./new_m9.png", 4, 3,450,15,6,6)
                if(warrior.level == 5):
                    monster2 = Monstro("./new_m10.png", 4, 3,500,15,6,6)
                
                    
                
                    
                
        if(monster1.vidaMonstro <= 0 and monster1.vivo == False):
            agora = pygame.time.get_ticks()
            
            if(monster2.vivo == True and monster1.vivo == False):
                monster1.dano = 0
           
            
            if (agora - pegaTempo >= cooldown):
                pegaTempo = agora
                warrior.XP += 25
                magia.usouMagia = False
                if(warrior.level >= 0 or warrior.level == 1):
                    monster1 = Monstro("./new_m10.png", 4, 3,400,15,6,6)
                if(warrior.level == 2):
                    monster1 = Monstro("./new_m5.png", 4, 3,400,15,6,6)
                if(warrior.level == 3):
                    monster1 = Monstro("./new_m6.png", 4, 3,350,15,6,6)
                if(warrior.level == 4):
                    monster1 = Monstro("./new_m7.png", 4, 3,300,15,6,6)
                if(warrior.level == 5):
                    monster1 = Monstro("./new_m8.png", 4, 3,450,15,6,6)    
                
            
        warrior.update()             
        monster1.moverMonstro(warrior)
        monster2.moverMonstro(warrior)
    
      
        warrior.levelUp(screen)
        if(magia.usouMagia == False):
            magia.moverMagia(warrior)
        if(warrior.XP >= 100 and warrior.XP <= 110):
            warrior.level = 2
        if(warrior.XP >= 400 and warrior.XP <= 510):
            warrior.level = 3
        if(warrior.XP >= 600 and warrior.XP <= 710):
            warrior.level = 4
        if(warrior.XP >= 800 and warrior.XP <= 810):
            warrior.level = 5    
            
        #if(warrior.level == 5):
            #telaGameOver()
        
        pygame.display.update()
        FPSCLOCK.tick(FPS)        

rodaJogo()
