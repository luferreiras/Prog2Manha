#!/usr/bin/env python
#-*- coding: utf-8 -*-


import pygame
from pygame.locals import *


class App:
	def __init__(self):
		self.screen = [1600, 900]
		self.maincolor = [154, 197, 12]
		self.white = [255, 255, 255]
		self.background = pygame.image.load("./menu.png")
		self.menu = [" Menu1 ", " Menu2 ", " Menu3 ", " Menu4 ", " Menu5 "]
		self.menuall = ""
		self.selectedmenu = 0
		self.mid = []
		
		# colocas as opçoes
		pygame.init()
		self.screen = pygame.display.set_mode(self.screen, 0, 32)
		pygame.display.set_caption("BMenu")
		# pega a largura do meu
		self.menuid()
		# todos os menus em um:
		self.listmenuall()
		# loop principal
		while True:
			for self.event in pygame.event.get():
				if self.event.type == pygame.QUIT:
					exit()
				if self.event.type == pygame.KEYDOWN:
					if self.event.key == pygame.K_LEFT:
						if self.selectedmenu == 0:
							self.selectedmenu = len(self.menu)-1
							
						else:
							self.selectedmenu = self.selectedmenu-1
					elif self.event.key == pygame.K_RIGHT:
						if self.selectedmenu == len(self.menu)-1:
							self.selectedmenu = 0
						else:
							self.selectedmenu = self.selectedmenu+1
			
			# 1 camada: cor de fundo
			self.screen.fill(self.maincolor)
			# 2 camada : menus
			self.crt_menu()
			# 3 camada imagem transparente
			self.screen.blit(self.background, (0, 0))
			
			pygame.display.flip()
			
	def menuid(self):
		for n in self.menu:
			font = pygame.font.SysFont("arial", 40)
			text_surface = font.render(n, True, self.white)
			self.mid.append(text_surface.get_width())
			
	def listmenuall(self):
		for n in self.menu:
			self.menuall = self.menuall+n
			
	def crt_menu(self):
		nmb = 0
		xpos = 0
		while nmb <= self.selectedmenu:
			xpos = xpos-self.mid[nmb]
			nmb = nmb+1
		xpos = xpos+self.mid[self.selectedmenu]/2
		# desenha os menus na tela
		font = pygame.font.SysFont("arial", 40)
		text_surface = font.render(self.menuall, True, self.white)
		self.screen.blit(text_surface, (400+xpos, 280))



if __name__ == "__main__":
	App()
