import pygame,math,time
from random import randint
from pygame.locals import *
from Heroi import Heroi
from drop import Drop


class Magia():
    
    def __init__(self,imageNome,linhas,colunas,Heroi):
        
        self.x = -15
        self.y = -15
        self.velY = 0
        self.velX = 0
        self.dano = 15
        self.usouMagia = False
        
        self.img = pygame.image.load(imageNome)
     
        self.epa_images = []
        
        self.width = self.img.get_width() / colunas
        
        self.height = (self.img.get_height()) / linhas
        
        for linha in range(linhas):
            for coluna in range(colunas):
                x = coluna * self.width 
                y = linha * self.height
                frame = self.img.subsurface((x,y),(self.width,self.height))
                self.epa_images.append(frame)
                               
        epaCima = [0, 1, 2, 3, 4]
        epaBaixo = [10, 11, 12, 13, 14]
        epaEsquerda = [5, 6, 7, 8, 9]
        epaDireita = [15, 16, 17, 18, 19]
        epaDefault = [0]
        
        
        self.estados = {"CIMA": epaCima,
                        "BAIXO":epaBaixo,
                        "ESQUERDA":epaEsquerda,
                        "DIREITA":epaDireita,
                        "NADA":epaDefault}

        self.estado = "NADA"
        
        self.numeroQuadro = 0
        
        self.rect = Rect ( (self.x, self.y), (self.width , self.height ) )
        
    def retornaQuadro(self):
        
        quadros = self.estados[self.estado]
        self.numeroQuadro = self.numeroQuadro % len(quadros)
        indImagem = quadros[self.numeroQuadro]
        imagem = self.epa_images[indImagem]    
        self.numeroQuadro = self.numeroQuadro + 1
    
        return imagem
    
    def draw(self,sur):
        
        quadro = self.retornaQuadro()
        if(self.usouMagia == False):
            sur.blit(quadro,(self.rect.x,self.rect.y))
        else:
            self.rect.x = -15
            self.rect.y = -15
            self.velX = 0
            self.velY = 0       
 
    def testaMovimento(self):

        r = Rect ( (self.rect.x + self.velX, self.rect.y + self.velY), self.rect.size)
        
        return r

                
    def moverMagia(self,Heroi):
        if(self.usouMagia == True):
            self.velX = 0
            self.velY = 0
        else:    
            if(self.estado == "DIREITA"):
                self.rect.x += self.velX
           
                
            if(self.estado == "ESQUERDA"):
                self.rect.x -= self.velX
              
                
            if(self.estado == "CIMA"):
                self.rect.y -= self.velY
            
                
            if(self.estado == "BAIXO"):
                self.rect.y += self.velX
                          