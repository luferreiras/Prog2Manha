import pygame,math,time
from random import randint
from pygame.locals import *
from Heroi import Heroi


class Drop():
    
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.velY = 400
        self.velX = 400
        self.linhas = 1
        self.colunas = 4        
        
        self.img = pygame.image.load("./life.png")
               
        self.epa_images = []
        
        self.width = (self.img.get_width() - 40) / self.colunas 
        self.height = self.img.get_height() / self.linhas
        
        
        for linha in range(self.linhas):
            for coluna in range(self.colunas):
                x = coluna * self.width 
                y = linha * self.height
                frame = self.img.subsurface((x,y),(self.width,self.height))
                self.epa_images.append(frame)
                               
        epaDrop = [0, 1, 2, 3]
         

        self.estados = {"DROP": epaDrop}

        self.estado = "DROP"
        self.numeroQuadro = 0
        self.rect = Rect ( (self.x, self.y), (self.width, self.height) )
        
    def retornaQuadro(self):
        quadros = self.estados[self.estado]
        self.numeroQuadro = self.numeroQuadro % len(quadros)
        indImagem = quadros[self.numeroQuadro]
        imagem = self.epa_images[indImagem]    
        self.numeroQuadro = self.numeroQuadro + 1
    
        return imagem
    
    def draw(self,sur):
        
        quadro = self.retornaQuadro()
        sur.blit(quadro,(self.rect.x,self.rect.y))
       